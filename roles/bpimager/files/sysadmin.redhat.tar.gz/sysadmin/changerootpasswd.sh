echo $1 | passwd root --stdin
