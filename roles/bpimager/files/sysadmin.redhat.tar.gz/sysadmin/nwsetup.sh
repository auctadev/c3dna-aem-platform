#!/bin/sh
## Centos 5.2 Network Setup shell script
## Tier 3, March 20th, 2009
## arguments expected: hostname.domain ipaddr subnet gateway dns1 dns2
if [ $# -ne 6 ]; then
        echo Not enough arguments
        echo Usage: nwsetup.sh hostname.domain ipaddress subnet gateway dns1 dns2
        exit 127
fi
## get existing MAC Address from /etc/sysconfig/network-scripts/ifcfg-eth0
MA=`cat /etc/sysconfig/network-scripts/ifcfg-eth0 | grep HWADDR | sed 's/HWADDR=\(.*\)$/\1/'`
## split hostname and domain from argument 1 into variables
HN=`echo $1 | sed 's/\([^.]*\)\.\(.*\)$/\1/'`
DN=`echo $1 | sed 's/\([^.]*\)\.\(.*\)$/\2/'`
## stop networking service
echo Stopping network services...
/etc/init.d/network stop
## delete existing files
echo Deleting default configuration files...
rm -f /etc/resolv.conf
rm -f /etc/sysconfig/network
rm -f /etc/sysconfig/network-scripts/ifcfg-eth0
## generate /etc/sysconfig/network
echo Generating new files...
echo NETWORKING=yes > /etc/sysconfig/network
echo NETWORKING_IPV6=no >> /etc/sysconfig/network
echo HOSTNAME=$HN >> /etc/sysconfig/network
## generate /etc/resolv.conf
echo search $DN > /etc/resolv.conf
echo nameserver $5 >> /etc/resolv.conf
echo nameserver $6 >> /etc/resolv.conf
## generate /etc/sysconfig/network-scripts/ifcfg-eth0
echo DEVICE=eth0 > /etc/sysconfig/network-scripts/ifcfg-eth0
echo BOOTPROTO=none >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo HWADDR=$MA >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo ONBOOT=yes >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo TYPE=Ethernet >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo NETMASK=$3 >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo IPADDR=$2 >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo GATEWAY=$4 >> /etc/sysconfig/network-scripts/ifcfg-eth0
## start network service
echo Start network interfaces...
/etc/init.d/network start

