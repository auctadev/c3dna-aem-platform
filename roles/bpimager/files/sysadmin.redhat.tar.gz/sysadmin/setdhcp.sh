#!/bin/sh

echo DEVICE=eth0  > /etc/sysconfig/network-scripts/ifcfg-eth0
echo BOOTPROTO=dhcp  >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo ONBOOT=yes  >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo TYPE=Ethernet  >> /etc/sysconfig/network-scripts/ifcfg-eth0
## Restart network service
echo Restart network interfaces...
/etc/init.d/network restart
