#!/bin/sh
## Centos 5.2 Network Setup shell script
## Tier 3, March 20th, 2009
## arguments expected: hostname.domain ipaddr subnet gateway dns1 dns2
if [ $# -ne 1 ]; then
        echo Not enough arguments
        echo Usage: sethostname.sh hostname.domain
        exit 127
fi
## split hostname and domain from argument 1 into variables
HN=`echo $1 | sed 's/\([^.]*\)\.\(.*\)$/\1/'`
DN=`echo $1 | sed 's/\([^.]*\)\.\(.*\)$/\2/'`
## delete existing files
echo Deleting default configuration files...
rm -f /etc/sysconfig/network
## generate /etc/sysconfig/network
echo Generating new files...
echo NETWORKING=yes > /etc/sysconfig/network
echo NETWORKING_IPV6=no >> /etc/sysconfig/network
echo HOSTNAME=$HN >> /etc/sysconfig/network
