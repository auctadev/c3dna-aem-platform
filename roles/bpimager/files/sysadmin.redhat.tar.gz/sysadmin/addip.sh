#!/bin/sh
## Centos 5.2 Network Setup shell script
## Tier 3, March 20th, 2009
## arguments expected: hostname.domain ipaddr subnet gateway dns1 dns2
if [ $# -ne 2 ]; then
        echo Not enough arguments
        echo Usage: nwsetup.sh ipaddress subnet
        exit 127
fi

## get Device count
IPCount=`ls -1 /etc/sysconfig/network-scripts/ifcfg-eth0* | wc -l`
## get existing MAC Address from /etc/sysconfig/network-scripts/ifcfg-eth0
MA=`cat /etc/sysconfig/network-scripts/ifcfg-eth0 | grep HWADDR | sed 's/HWADDR=\(.*\)$/\1/'`
## generate /etc/sysconfig/network-scripts/ifcfg-eth0:new
echo DEVICE=eth0:$IPCount >> /etc/sysconfig/network-scripts/ifcfg-eth0:$IPCount
echo BOOTPROTO=none >> /etc/sysconfig/network-scripts/ifcfg-eth0:$IPCount
echo HWADDR=$MA >> /etc/sysconfig/network-scripts/ifcfg-eth0:$IPCount
echo ONBOOT=yes >> /etc/sysconfig/network-scripts/ifcfg-eth0:$IPCount
echo TYPE=Ethernet >> /etc/sysconfig/network-scripts/ifcfg-eth0:$IPCount
echo NETMASK=$2 >> /etc/sysconfig/network-scripts/ifcfg-eth0:$IPCount
echo IPADDR=$1 >> /etc/sysconfig/network-scripts/ifcfg-eth0:$IPCount
echo GATEWAY= >> /etc/sysconfig/network-scripts/ifcfg-eth0:$IPCount
## Restart network service
echo Restart network interfaces...
/etc/init.d/network restart

